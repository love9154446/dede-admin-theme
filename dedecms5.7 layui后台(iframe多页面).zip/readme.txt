假设你的网站为http://www.baidu.com
假设你的后台为http://www.baidu.com/dede/

只需要按以下步骤轻松使用该后台模板(支持dedecms5.7):
一:将assets文件夹复制到后台目录下http://www.baidu.com/dede/,确保该文件夹访问地址为http://www.baidu.com/dede/assets/
二:将index2.htm index_body.htm login.htm 复制到后台templets目录下,覆盖原有文件,正确地址应为http://www.baidu.com/dede/templets/index2.htm等

注意:覆盖前,备份好三个html文件,不想使用的收,轻松还原回原来的模板.此模板不需要修改任何php文件.支持后台页面iframe多页面同时打开.
作者QQ:9154446 个人制作,只做分享,不喜勿喷.
github地址:https://github.com/love9154446/dede-admin-theme